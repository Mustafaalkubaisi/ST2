import time
import random
import string
import tkinter as tk
from tkinter import ttk, messagebox


# ===== BST Node and BST Class =====

class Node:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, root, name, phone):
        if root is None:
            return Node(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root

    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)

    def inorder(self, root, result=None):
        if result is None:
            result = []
        if root:
            self.inorder(root.left, result)
            result.append((root.name, root.phone))
            self.inorder(root.right, result)
        return result


# ===== AVL Node and AVL Tree Class =====

class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1


class AVLTree:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)

    def right_rotate(self, z):
        y = z.left
        T3 = y.right

        y.right = z
        z.left = T3

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def left_rotate(self, z):
        y = z.right
        T2 = y.left

        y.left = z
        z.right = T2

        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y

    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)
        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node

        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)

        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)

        return node

    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        else:
            return self.search(node.right, name)

    def inorder(self, root, result=None):
        if result is None:
            result = []
        if root:
            self.inorder(root.left, result)
            result.append((root.name, root.phone))
            self.inorder(root.right, result)
        return result


# ===== Red-Black Node and Red-Black Tree Class =====

class RBNode:
    def __init__(self, name=None, phone=None, color="black"):
        self.name = name
        self.phone = phone
        self.color = color
        self.left = None
        self.right = None
        self.parent = None


class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode()
        self.root = self.NIL

    def left_rotate(self, x):
        y = x.right
        x.right = y.left

        if y.left != self.NIL:
            y.left.parent = x

        y.parent = x.parent

        if x.parent is None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y

        y.left = x
        x.parent = y

    def right_rotate(self, y):
        x = y.left
        y.left = x.right

        if x.right != self.NIL:
            x.right.parent = y

        x.parent = y.parent

        if y.parent is None:
            self.root = x
        elif y == y.parent.right:
            y.parent.right = x
        else:
            y.parent.left = x

        x.right = y
        y.parent = x

    def insert(self, name, phone):
        node = RBNode(name, phone, "red")
        node.left = self.NIL
        node.right = self.NIL

        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if node.name < current.name:
                current = current.left
            elif node.name > current.name:
                current = current.right
            else:
                current.phone = phone
                return

        node.parent = parent

        if parent is None:
            self.root = node
        elif node.name < parent.name:
            parent.left = node
        else:
            parent.right = node

        self.fix_insert(node)

    def fix_insert(self, k):
        while k != self.root and k.parent.color == "red":
            if k.parent == k.parent.parent.left:
                u = k.parent.parent.right

                if u.color == "red":
                    k.parent.color = "black"
                    u.color = "black"
                    k.parent.parent.color = "red"
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = "black"
                    k.parent.parent.color = "red"
                    self.right_rotate(k.parent.parent)
            else:
                u = k.parent.parent.left

                if u.color == "red":
                    k.parent.color = "black"
                    u.color = "black"
                    k.parent.parent.color = "red"
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = "black"
                    k.parent.parent.color = "red"
                    self.left_rotate(k.parent.parent)

        self.root.color = "black"

    def search(self, node, name):
        while node != self.NIL and node.name != name:
            if name < node.name:
                node = node.left
            else:
                node = node.right
        if node == self.NIL:
            return None
        return node

    def inorder(self, node, result=None):
        if result is None:
            result = []
        if node != self.NIL:
            self.inorder(node.left, result)
            result.append((node.name, node.phone, node.color))
            self.inorder(node.right, result)
        return result


# ===== Benchmarking Function =====

def benchmark_three_trees(n=1000):
    names = [''.join(random.choices(string.ascii_lowercase, k=8)) for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]

    bst = BST()
    start = time.time()
    for i in range(n):
        bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_insert = time.time() - start

    start = time.time()
    for name in names[:n // 2]:
        bst.search(bst.root, name)
    bst_search = time.time() - start

    avl = AVLTree()
    start = time.time()
    for i in range(n):
        avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_insert = time.time() - start

    start = time.time()
    for name in names[:n // 2]:
        avl.search(avl.root, name)
    avl_search = time.time() - start

    rb = RedBlackTree()
    start = time.time()
    for i in range(n):
        rb.insert(names[i], phones[i])
    rb_insert = time.time() - start

    start = time.time()
    for name in names[:n // 2]:
        rb.search(rb.root, name)
    rb_search = time.time() - start

    return {
        "BST Insert": bst_insert,
        "BST Search": bst_search,
        "AVL Insert": avl_insert,
        "AVL Search": avl_search,
        "RB Insert": rb_insert,
        "RB Search": rb_search
    }


# ===== Tkinter GUI for Red-Black Tree =====

class RBTreeApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Red-Black Tree Contact Directory")
        self.tree = RedBlackTree()

        frame = tk.Frame(master)
        frame.pack(pady=10)

        tk.Label(frame, text="Name:").grid(row=0, column=0, padx=5)
        self.name_entry = tk.Entry(frame)
        self.name_entry.grid(row=0, column=1, padx=5)

        tk.Label(frame, text="Phone:").grid(row=1, column=0, padx=5)
        self.phone_entry = tk.Entry(frame)
        self.phone_entry.grid(row=1, column=1, padx=5)

        button_frame = tk.Frame(master)
        button_frame.pack()

        tk.Button(button_frame, text="Insert", command=self.insert_contact).grid(row=0, column=0, padx=5)
        tk.Button(button_frame, text="Search", command=self.search_contact).grid(row=0, column=1, padx=5)
        tk.Button(button_frame, text="Show All", command=self.show_all).grid(row=0, column=2, padx=5)
        tk.Button(button_frame, text="Run Benchmark", command=self.run_benchmark).grid(row=0, column=3, padx=5)

        self.output_text = tk.Text(master, height=12, width=70)
        self.output_text.pack(pady=10)

        self.canvas = tk.Canvas(master, width=900, height=300, bg="white")
        self.canvas.pack(pady=10)

        self.table = ttk.Treeview(master, columns=("Structure", "Time"), show="headings")
        self.table.heading("Structure", text="Structure")
        self.table.heading("Time", text="Time (s)")
        self.table.pack(pady=10)

    def insert_contact(self):
        name = self.name_entry.get().strip()
        phone = self.phone_entry.get().strip()

        if not name or not phone:
            messagebox.showwarning("Input Error", "Please enter both Name and Phone.")
            return

        self.tree.insert(name, phone)
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)
        self.show_all()
        self.draw_tree()

    def search_contact(self):
        name = self.name_entry.get().strip()
        self.output_text.delete(1.0, tk.END)

        if not name:
            self.output_text.insert(tk.END, "Please enter a name to search.\n")
            return

        node = self.tree.search(self.tree.root, name)
        if node:
            self.output_text.insert(tk.END, f"Found Contact:\nName: {node.name}\nPhone: {node.phone}\nColor: {node.color}\n")
        else:
            self.output_text.insert(tk.END, "Contact not found.\n")

    def show_all(self):
        self.output_text.delete(1.0, tk.END)
        contacts = self.tree.inorder(self.tree.root)

        if not contacts:
            self.output_text.insert(tk.END, "No contacts found.\n")
        else:
            for name, phone, color in contacts:
                self.output_text.insert(tk.END, f"Name: {name}, Phone: {phone}, Color: {color}\n")

    def draw_tree(self):
        self.canvas.delete("all")
        if self.tree.root == self.tree.NIL:
            return
        self._draw_node(self.tree.root, 450, 30, 200)

    def _draw_node(self, node, x, y, x_offset):
        if node == self.tree.NIL:
            return

        radius = 20

        if node.left != self.tree.NIL:
            x_left = x - x_offset
            y_left = y + 70
            self.canvas.create_line(x, y + radius, x_left, y_left - radius)
            self._draw_node(node.left, x_left, y_left, max(40, x_offset // 2))

        if node.right != self.tree.NIL:
            x_right = x + x_offset
            y_right = y + 70
            self.canvas.create_line(x, y + radius, x_right, y_right - radius)
            self._draw_node(node.right, x_right, y_right, max(40, x_offset // 2))

        fill_color = "red" if node.color == "red" else "black"
        self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=fill_color)
        display_name = node.name if len(node.name) <= 8 else node.name[:8]
        self.canvas.create_text(x, y, text=display_name, fill="white")

    def run_benchmark(self):
        results = benchmark_three_trees(1000)

        self.output_text.delete(1.0, tk.END)
        self.output_text.insert(
            tk.END,
            f"BST Insert: {results['BST Insert']:.6f}s\n"
            f"BST Search: {results['BST Search']:.6f}s\n"
            f"AVL Insert: {results['AVL Insert']:.6f}s\n"
            f"AVL Search: {results['AVL Search']:.6f}s\n"
            f"RB Insert: {results['RB Insert']:.6f}s\n"
            f"RB Search: {results['RB Search']:.6f}s\n"
        )

        for row in self.table.get_children():
            self.table.delete(row)

        self.table.insert("", tk.END, values=("BST Insert", f"{results['BST Insert']:.6f}"))
        self.table.insert("", tk.END, values=("BST Search", f"{results['BST Search']:.6f}"))
        self.table.insert("", tk.END, values=("AVL Insert", f"{results['AVL Insert']:.6f}"))
        self.table.insert("", tk.END, values=("AVL Search", f"{results['AVL Search']:.6f}"))
        self.table.insert("", tk.END, values=("RB Insert", f"{results['RB Insert']:.6f}"))
        self.table.insert("", tk.END, values=("RB Search", f"{results['RB Search']:.6f}"))


if __name__ == "__main__":
    root = tk.Tk()
    app = RBTreeApp(root)
    root.mainloop()