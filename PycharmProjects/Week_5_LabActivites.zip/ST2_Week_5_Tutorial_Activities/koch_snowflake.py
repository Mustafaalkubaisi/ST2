from tkinter import *  # Import tkinter
from math import *


class KochSnowflake:
    def __init__(self):

        window = Tk()  # Create a window
        window.title("koch snowflake")  # Set a title
        self.width = 600
        self.height = 600
        self.x = 25
        self.y = 200
        self.angle = 0
        self.canvas = Canvas(window,
                     width=self.width, height=self.height)
        self.canvas.pack()


# Add a label, an entry, and a button to frame1
        frame1 = Frame(window)  # Create and add a frame to window
        frame1.pack()

        Label(frame1,
            text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        entry = Entry(frame1, textvariable=self.order, justify=RIGHT).pack(side=LEFT)
        Button(frame1, text="Display", command=self.display).pack(side=LEFT)

        window.mainloop()  # Create an event loop


    def display(self):
        self.canvas.delete("line")
        self.x = 25
        self.y = 200
        self.angle = 0
        for i in range(3):
            self.Koch(300, int(self.order.get()))
            self.right(120)


    def Koch(self, length, order):
        if order == 0:
            self.forward(length)
        else:
            length /= 3
            self.Koch(length, order-1)
            self.left(60)
            self.Koch(length, order-1)
            self.right(120)
            self.Koch(length, order-1)
            self.left(60)
            self.Koch(length, order-1)

    def forward(self, length):
        x2 = self.x + length * cos(radians(self.angle))
        y2 = self.y - length * sin(radians(self.angle))
        self.canvas.create_line(self.x, self.y, x2, y2, tags="line")
        self.x = x2
        self.y = y2

    def right(self, degrees):
        self.angle -= degrees

    def left(self, degrees):
        self.angle += degrees








KochSnowflake()  # Create GUI